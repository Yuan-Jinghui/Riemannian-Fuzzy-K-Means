# -*- coding: utf-8 -*-
"""
Created on Wed Jul 30 19:18:09 2025

@author: lenovo
"""


import numpy as np
from sklearn.metrics import (
    normalized_mutual_info_score,
    adjusted_rand_score,
    precision_score,
    recall_score,
    f1_score
)
from scipy.optimize import linear_sum_assignment
from collections import Counter

def compute_label_alignment(y_true, y_pred):
    y_true = np.asarray(y_true)
    y_pred = np.asarray(y_pred)
    D = max(y_pred.max(), y_true.max()) + 1
    w = np.zeros((D, D), dtype=np.int64)
    for i in range(y_pred.size):
        w[y_pred[i], y_true[i]] += 1
    row_ind, col_ind = linear_sum_assignment(w.max() - w)
    mapping = {row: col for row, col in zip(row_ind, col_ind)}
    y_pred_aligned = np.array([mapping[label] for label in y_pred])
    acc = sum(w[i, j] for i, j in zip(row_ind, col_ind)) / y_pred.size
    return acc, y_pred_aligned

def purity_score(y_true, y_pred):
    y_true = np.asarray(y_true)
    y_pred = np.asarray(y_pred)
    total = 0
    for cluster in np.unique(y_pred):
        indices = np.where(y_pred == cluster)[0]
        true_labels = y_true[indices]
        most_common = Counter(true_labels).most_common(1)
        if most_common:
            total += most_common[0][1]
    return total / len(y_true)

def evaluate(y_true, y_pred, method='macro'):
    y_true = np.asarray(y_true)
    y_pred = np.asarray(y_pred)

    # ACC & aligned labels
    acc, y_pred_aligned = compute_label_alignment(y_true, y_pred)

    # Metrics
    nmi = normalized_mutual_info_score(y_true, y_pred)
    purity = purity_score(y_true, y_pred)
    precision = precision_score(y_true, y_pred_aligned, average=method, zero_division=0)
    recall = recall_score(y_true, y_pred_aligned, average=method, zero_division=0)
    f1 = f1_score(y_true, y_pred_aligned, average=method, zero_division=0)
    ari = adjusted_rand_score(y_true, y_pred)

    return np.array([acc, nmi, purity, f1, precision, recall, ari])

import torch
from manify.manifolds import ProductManifold
#from manify.clustering.fuzzy_kmeans_test import RiemannianFuzzyKMeans
from manify.clustering.fuzzy_kmeans import RiemannianFuzzyKMeans
import numpy as np

# 1. Define the signature: a 3-factor manifold
import numpy as np
#    (curvature, dimension)
import time

import pandas as pd
import numpy as np

# 读取 Excel 文件（没有表头）
time_list=np.zeros((7,2))
loss_list=[]
file_list=['guass_r4','guass_h4','guass_s2h2','guass_r2s2h2','guass_s2h2h2','guass_r4s4h4','guass_r16s16h16']
signature_list=[[(0,4)],[(-1,4)],[(1,2),(-1,2)],[(0,2),(1,2),(-1,2)],[(1,2),(-1,2),(-1,2)],[(0,4),(1,4),(-1,4)],[(0,16),(1,16),(-1,16)],
    ]

for i in range(7):
    df = pd.read_excel(r'E:\360MoveData\Users\lenovo\Desktop\Data\\'+file_list[i]+'.xlsx', header=None)  # header=None 表示没有表头

# 转换为 numpy 数组
    data = df.values

# 拆分特征和标签
    X = data[:, :-1]       # 除最后一列之外的所有列
    y_true = data[:, -1]   # 最后一列作为标签

# 打印形状确认
    print("X shape:", X.shape)
    print("y_true shape:", y_true.shape)



# 2. Construct the ProductManifold (without stereographic projection)
    P = ProductManifold(signature_list[i], device="cpu", stereographic=False)

#setting param
    n_clusters = 3

    opt = 'adan'
    lr = .5
    tol = 1e-4

# 3. Generate data using gaussian_mixture
#    - num_points=500: sample 500 points
#    - num_classes=n_clusters: generate n_clusters class labels (for clustering)
#    - seed=seed: fix the random seed for reproducibility


# 3. Generate data using gaussian_mixture
#    - num_points=500: sample 500 points
#    - num_classes=n_clusters: generate n_clusters class labels (for clustering)
#    - seed=seed: fix the random seed for reproducibility


    model = RiemannianFuzzyKMeans(n_clusters, 
            random_state=1,
            pm=P, 
            max_iter=100,
            tol=tol,
            optimizer=opt,
            lr=lr,
            verbose=True,)
            #track_loss=True)
    t1=time.time()
    labels = model.fit_predict(X)
    t2=time.time()

#result = evaluate(y_true, labels).reshape(1, -1)


    #from manify.clustering.kmeans_test import RiemannianKMeans
    '''model_rkm = RiemannianKMeans(n_clusters, 
            pm=P, 
            max_iter=100,
            tol=tol,
            optimizer=opt,
            lr=lr,
            verbose=True,
            track_loss=True,
            random_state=0,
            )
    t3=time.time()
    labels_rkm = model_rkm.fit_predict(X)
    t4=time.time()'''
#result3 = evaluate(y_true, labels_rkm).reshape(1, -1)

    #print(t2-t1,t4-t3)
    print(t2-t1)
    loss_list.append(model.losses_)
    #loss_list.append(model_rkm.losses_)
    time_list[i,0]=t2-t1
    #time_list[i,1]=t4-t3