# -*- coding: utf-8 -*-
"""
Created on Wed Jul 30 19:18:09 2025

@author: lenovo
"""


import numpy as np
from sklearn.metrics import (
    normalized_mutual_info_score,
    adjusted_rand_score,
    precision_score,
    recall_score,
    f1_score
)
from scipy.optimize import linear_sum_assignment
from collections import Counter

def compute_label_alignment(y_true, y_pred):
    y_true = np.asarray(y_true)
    y_pred = np.asarray(y_pred)
    D = max(y_pred.max(), y_true.max()) + 1
    w = np.zeros((D, D), dtype=np.int64)
    for i in range(y_pred.size):
        w[y_pred[i], y_true[i]] += 1
    row_ind, col_ind = linear_sum_assignment(w.max() - w)
    mapping = {row: col for row, col in zip(row_ind, col_ind)}
    y_pred_aligned = np.array([mapping[label] for label in y_pred])
    acc = sum(w[i, j] for i, j in zip(row_ind, col_ind)) / y_pred.size
    return acc, y_pred_aligned

def purity_score(y_true, y_pred):
    y_true = np.asarray(y_true)
    y_pred = np.asarray(y_pred)
    total = 0
    for cluster in np.unique(y_pred):
        indices = np.where(y_pred == cluster)[0]
        true_labels = y_true[indices]
        most_common = Counter(true_labels).most_common(1)
        if most_common:
            total += most_common[0][1]
    return total / len(y_true)

def evaluate(y_true, y_pred, method='macro'):
    y_true = np.asarray(y_true)
    y_pred = np.asarray(y_pred)

    # ACC & aligned labels
    acc, y_pred_aligned = compute_label_alignment(y_true, y_pred)

    # Metrics
    nmi = normalized_mutual_info_score(y_true, y_pred)
    purity = purity_score(y_true, y_pred)
    precision = precision_score(y_true, y_pred_aligned, average=method, zero_division=0)
    recall = recall_score(y_true, y_pred_aligned, average=method, zero_division=0)
    f1 = f1_score(y_true, y_pred_aligned, average=method, zero_division=0)
    ari = adjusted_rand_score(y_true, y_pred)

    return np.array([acc, nmi, purity, f1, precision, recall, ari])

import torch
from manify.manifolds import ProductManifold
from manify.clustering.fuzzy_kmeans_test import RiemannianFuzzyKMeans
import numpy as np

# 1. Define the signature: a 3-factor manifold
import numpy as np
#    (curvature, dimension)
import time

import pandas as pd
import numpy as np


adan_list=[]
adam_list=[]
# 读取 Excel 文件（没有表头）
file_list=['guass_r4','guass_h4','guass_s2h2','guass_r2s2h2','guass_s2h2h2','guass_r4s4h4','guass_r16s16h16'
           ,'citeseer_h2h2','core_h4','polblogs_s2s2']
signature_list=[[(0,4)],[(-1,4)],[(1,2),(-1,2)],[(0,2),(1,2),(-1,2)],[(1,2),(-1,2),(-1,2)],[(0,4),(1,4),(-1,4)],[(0,16),(1,16),(-1,16)],
    [(-1,2),(-1,2)],[(-1,4)],[(1,2),(1,2)]]
opt_list=['adan','adam']
lr_list=np.array([0.1,0.3,0.5,0.7,1])
n_clusters_list=[3,3,3,3,3,3,3,6,7,2]
for i in range(10):
    file_path = r'C:\Users\lenovo\Desktop\非欧嵌入数据集\\' + file_list[i] + '.xlsx'

    signature = signature_list[i]



    df = pd.read_excel(file_path, header=None)  # header=None 表示没有表头

# 转换为 numpy 数组
    data = df.values

# 拆分特征和标签
    X = data[:, :-1]       # 除最后一列之外的所有列
    y_true = data[:, -1]   # 最后一列作为标签

# 打印形状确认
    print("X shape:", X.shape)
    print("y_true shape:", y_true.shape)

#%%

# 2. Construct the ProductManifold (without stereographic projection)
    P = ProductManifold(signature, device="cpu", stereographic=False)
    
#setting param
    n_clusters = n_clusters_list[i]
    tol=0
    for j in range(len(opt_list)):
        loss_list_tem=[]
        for k in range(len(lr_list)):
            model = RiemannianFuzzyKMeans(n_clusters, 
                    random_state=10,
                    pm=P, 
                    max_iter=300,
                    tol=tol,
                    optimizer=opt_list[j],
                    lr=lr_list[k],
                    verbose=True,
                    track_loss=True)
            labels = model.fit_predict(X)
            loss_list_tem.append(model.losses_)
        if j%2==0:
            adan_list.append(loss_list_tem)
        else:
            adam_list.append(loss_list_tem)
            
    




