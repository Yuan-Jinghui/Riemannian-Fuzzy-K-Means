
import os

if os.getenv("BEARTYPE_ENABLE", "false").lower() == "true":
    from jaxtyping import install_import_hook

    install_import_hook("AnonymousLibrary", "beartype.beartype")
    print("Beartype import hook installed for AnonymousLibrary. Will use beartype for type checking.")

from AnonymousLibrary.clustering import RiemannianFuzzyKMeans
from AnonymousLibrary.curvature_estimation import delta_hyperbolicity, greedy_signature_selection, sectional_curvature
from AnonymousLibrary.embedders import CoordinateLearning, ProductSpaceVAE, SiameseNetwork
from AnonymousLibrary.manifolds import Manifold, ProductManifold
from AnonymousLibrary.predictors import KappaGCN, ProductSpaceDT, ProductSpacePerceptron, ProductSpaceRF, ProductSpaceSVM

# import manify.utils

# Define version and other package metadata
__version__ = "0.0.2"
__author__ = "Philippe Chlenski"
__email__ = "pac@cs.columbia.edu"
__license__ = "MIT"

# Export modules
__all__ = [
    # AnonymousLibrary.manifolds
    "Manifold",
    "ProductManifold",
    # AnonymousLibrary.embedders
    "CoordinateLearning",
    "ProductSpaceVAE",
    "SiameseNetwork",
    # AnonymousLibrary.predictors
    "ProductSpaceDT",
    "ProductSpaceRF",
    "KappaGCN",
    "ProductSpacePerceptron",
    "ProductSpaceSVM",
    # AnonymousLibrary.curvature_estimation
    "delta_hyperbolicity",
    "sectional_curvature",
    "greedy_signature_selection",
    # AnonymousLibrary.clustering
    "RiemannianFuzzyKMeans",
    # no utils
]
